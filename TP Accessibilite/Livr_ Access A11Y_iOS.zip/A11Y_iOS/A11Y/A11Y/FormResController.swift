//
//  FormResController.swift
//  A11Y
//
//  Created by Joshua Hugo Valmy on 09/03/2018.
//  Copyright © 2018 Joshua Hugo Valmy. All rights reserved.
//

import Foundation
import UIKit



class FormResController : UIViewController{
    @IBOutlet weak var lblCivNomPre: UILabel!
    @IBOutlet weak var lblMail: UILabel!
    @IBOutlet weak var lblTel: UILabel!
    var txtCivNomPre:String = ""
    var txtMail:String = ""
    var txtTel:String = ""

    
    override func viewDidLoad() {
        super.viewDidLoad()
        assignation()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        
    }
    
    func assignation(){
        lblCivNomPre.text = txtCivNomPre
        lblMail.text = txtMail
        lblTel.text = txtTel
    }
    
    
    
    @IBAction func confirme(_ sender: Any) {
        navigationController?.popToRootViewController(animated: true)
    }
    
    
}
