//
//  NouvellePersonneViewController.swift
//  TP5
//
//  Created by Camille Guinaudeau on 23/02/2017.
//  Copyright © 2017 Camille Guinaudeau. All rights reserved.
//

import UIKit

class NouvellePersonneViewController: UIViewController {

    var nouvellePersonne : Personne = Personne()
    
    @IBOutlet var textNom: UITextField!
    @IBOutlet var textPrenom: UITextField!
    @IBOutlet var textTelephone: UITextField!
    @IBOutlet var textMail: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if (segue.identifier == "enregistrementNouvellePersonne") {
            nouvellePersonne.nom = textNom.text ?? "Dubois"
            nouvellePersonne.prenom = textPrenom.text ?? "Michel"
            nouvellePersonne.telephone = textTelephone.text ?? "0251458996"
            nouvellePersonne.mail = textMail.text ?? "m.dubois@gmail.com"
            print("nouvelle personne : \(nouvellePersonne.description)")
        }
    }
 

}
