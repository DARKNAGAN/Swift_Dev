//
//  ViewController.swift
//  Promotion
//
//  Created by Christian on 07/05/2018.
//  Copyright © 2018 Christian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        let Eleve1 = Etudiant(nom: "Boursier", age:29, numEtudiant:001);
        
        let Eleve2 = Etudiant(nom: "Boulier", age:24, numEtudiant:002);
        
        let Etudiants = [Eleve1, Eleve2];
        
        let Promo1 = Promotion(nom: "LPPRISM1", etudiants:Etudiants );
      
    //Change JSON
        let directories =   NSSearchPathForDirectoriesInDomains(.documentDirectory,                                                               FileManager.SearchPathDomainMask.userDomainMask, true)
        
        if let documents = directories.first {
            let fileName = documents.appending("/promotions.json")
            let url = URL(fileURLWithPath: fileName)
            let jsonEncoder = JSONEncoder()
            
        //Encoder
            do {
                let jsonData = try jsonEncoder.encode(Promo1)
                try jsonData.write(to:url)
            }
            catch {
                print("error")
            }
            
        //Decoder
            let jsonDecoder = JSONDecoder()
            do {
                let jsonDataNew = try Data(contentsOf:url)
                let promo2 = try jsonDecoder.decode(Promotion.self, from:
                    jsonDataNew)
                affiche(promotion: promo2);
            } catch {
                    print("error")
            }
        }
        
    }
    
    func affiche(promotion : Promotion){
            print("Promotion: " + promotion.nom)
            let etudiants = promotion.etudiants;
            print("Etudiants: ")
            for etudiant in etudiants {
                    print(etudiant.nom);
                    print(etudiant.age);
                    print(etudiant.numEtudiant);
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

