//
//  Promotion.swift
//  Promotion
//
//  Created by Christian on 07/05/2018.
//  Copyright © 2018 Christian. All rights reserved.
//

import UIKit

class Promotion: Codable {
    var nom : String
    var etudiants : [Etudiant];
    
    init(nom: String, etudiants: [Etudiant]) {
        self.nom = nom
        self.etudiants = etudiants
    }
    
}
