//
//  PanierViewController.swift
//  A11Y
//
//  Created by Joshua Hugo Valmy on 14/03/2018.
//  Copyright © 2018 Joshua Hugo Valmy. All rights reserved.
//

import Foundation
import UIKit

class PanierViewController : UIViewController{
    @IBOutlet weak var articles: UILabel!
    @IBOutlet weak var lblPrixTt: UILabel!
    
    var nbArticle1:Int = 0
    var nbArticle2:Int = 0
    
    let prixNbArticle1:Int = 200
    let prixNbArticle2:Int = 5
    
    var prixTt:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        calculate()
        refreshLbl()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    func calculate(){
            prixTt = (nbArticle1 * prixNbArticle1) + (nbArticle2 * prixNbArticle2)
    }
    
    func refreshLbl(){
        if(nbArticle1 == 0 && nbArticle2 == 0){
            articles.text = (
                "Aucun article.")
        }
        else if (nbArticle1 == 0){
            articles.text = ("Connecteur Micro-USB : \(nbArticle2)x" )
        }
        else if(nbArticle2 == 0){
            articles.text = ("Ordinateur Portable - Lewlette-Backard Lavilion 2000 : \(nbArticle1)x" )
        }
        else{
            articles.text = ("Ordinateur Portable - Lewlette-Backard Lavilion 2000 : \(nbArticle1)x\nConnecteur Micro-USB : \(nbArticle2)x")
        }
        lblPrixTt.text = "Prix total : \(String(prixTt))€"
    }
    
}
