//
//  Partie.swift
//  Puissance4
//
//  Created by Christian on 04/06/2018.
//  Copyright © 2018 Camille Guinaudeau. All rights reserved.
//

import Foundation


class Partie : Codable{
    var nomJoueur1 = String()
    var nomJoueur2 = String()
    var nbPartie = 0
    var nbPartieG1 = 0
    var nbPartieG2 = 0
    var nbPartienulle = 0
    var year : Int
    var month : Int
    var day : Int
    var hour : Int
    var minute : Int
    
    init(nomJoueur1 : String, nomJoueur2: String) {
        self.nomJoueur1 = nomJoueur1
        self.nomJoueur2 = nomJoueur2
        nbPartie += 1
        
        let date = Date()
        self.year = Calendar.current.component(.year, from: date)
        self.month = Calendar.current.component(.month, from: date)
        self.day = Calendar.current.component(.day, from: date)
        self.hour = Calendar.current.component(.hour, from: date)
        self.minute = Calendar.current.component(.minute, from: date)
    }
    
    func rejoue(){
        nbPartie += 1
    }
    
    func gagne(numJoueur : Int){
        if(numJoueur == 0){
            nbPartieG1 += 1
        }
        else{
            nbPartieG2 += 1
        }
        
    }
    
    func nulle(){
        nbPartienulle += 1
    }
    
}
