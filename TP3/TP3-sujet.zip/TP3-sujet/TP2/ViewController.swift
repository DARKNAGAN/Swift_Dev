//
//  ViewController.swift
//  TP2
//
//  Created by Camille Guinaudeau on 13/02/2018.
//  Copyright © 2018 Camille Guinaudeau. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var tableauVoitures : [Voiture] = []
    
    @IBOutlet weak var textMarque: UITextField!
    @IBOutlet weak var textModele: UITextField!
    @IBOutlet weak var textImmatriculation: UITextField!
    @IBOutlet weak var Typecarburant: UISegmentedControl!
    @IBOutlet weak var boiteAutomatique: UISwitch!
    @IBOutlet weak var affichageVoiture: UILabel!
    @IBOutlet weak var boutonEnregistrer: UIButton!
    @IBAction func EnregistrerNouvelleVoiture(_ sender: Any) {
        let nouvelleVoiture = Voiture()
        nouvelleVoiture.marque = textMarque.text!
        nouvelleVoiture.modele = textModele.text!
        nouvelleVoiture.immatriculation = textImmatriculation.text!
        var carbu = ""
        if (Typecarburant.selectedSegmentIndex == 0) {
            carbu = "Essence"
        }
        if (Typecarburant.selectedSegmentIndex == 1) {
            carbu = "Diesel"
        }
        if (Typecarburant.selectedSegmentIndex == 2) {
            carbu = "Electrique"
        }
        nouvelleVoiture.carburant = carbu
        nouvelleVoiture.boite = boiteAutomatique.isOn
        
        affichageVoiture.text =  nouvelleVoiture.description
        tableauVoitures.append(nouvelleVoiture)
        print("Nous avons enregistré \(tableauVoitures.count) voitures, les voici : ")
        for voiture in tableauVoitures {
            print(voiture.description)
        }
        self.cleanInterface()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.cleanInterface()
        
        let v1 = Voiture()
        let v2 = Voiture(marque: "Fiat", modele: "Uno", immatriculation: "XX-123-GT", boite: true, carburant: "Diesel")
        print(v1.description)
        print(v2.description)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func cleanInterface() {
        textMarque.text = ""
        textModele.text = ""
        textImmatriculation.text = ""
        Typecarburant.selectedSegmentIndex = UISegmentedControlNoSegment
        boiteAutomatique.isOn = true
        //boutonEnregistrer.isEnabled = false
    }
}

