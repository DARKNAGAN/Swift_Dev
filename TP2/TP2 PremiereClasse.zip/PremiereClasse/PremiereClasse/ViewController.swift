//
//  ViewController.swift
//  PremiereClasse
//
//  Created by Christian on 18/03/2018.
//  Copyright © 2018 Christian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var vView: UIView!
    @IBOutlet weak var vTFMarque: UITextField!
    @IBOutlet weak var vTFModele: UITextField!
    @IBOutlet weak var vTFImmat: UITextField!
    @IBOutlet weak var vSwitchBA: UISwitch!
    @IBOutlet weak var vSegCarb: UISegmentedControl!
    @IBOutlet weak var vLabelVoitureEnr: UILabel!
    @IBOutlet weak var vButtonSave: UIButton!
    @IBOutlet weak var VCloseEdit: UIButton!

    var marque : String  = ""
    var modele : String = ""
    var immat : String = ""
    var carb : String = ""
    var boite : Bool  = false
    var typeboite : String  = ""
    var voiture = ["Marque", "Modele", "Immatriculation", "Carburant", "Boite"]
    
    @IBAction func CloseEditAction(_ sender: UIButton) {
        view.endEditing(true)
    }

    @IBAction func fBTSave(_ sender: UIButton) {
        
        marque = self.vTFMarque.text!;
        modele = self.vTFModele.text!;
        immat = self.vTFImmat.text!;
        boite = self.vSwitchBA.isOn;
        
        if vSwitchBA.isOn == true {
            typeboite = "Automatique"
        } else {
            typeboite = "Manuel"
        }
        
        voiture.insert("\(marque)",at:0)
        voiture.insert("\(modele)",at:1)
        voiture.insert("\(immat)",at:2)
        voiture.insert("\(carb)",at:3)
        voiture.insert("\(typeboite)",at:4)
        
        carb = self.vSegCarb.titleForSegment(at:vSegCarb.selectedSegmentIndex)!;
        vLabelVoitureEnr.text = " Marque :\(marque)\n Modele : \(modele) \n Boite : \(typeboite) \n Immatriculation : \(immat) \n Carburant : \(carb)"
        
        print ("Tableau \(voiture) \n VoitureTotal : ",voiture.count)
    }
    
    
    
    
    
    //0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

