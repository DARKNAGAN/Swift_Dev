//
//  Voiture.swift
//  PremiereClasse
//
//  Created by Christian on 18/03/2018.
//  Copyright © 2018 Christian. All rights reserved.
//

import Foundation

class Voiture {
    var marque: String = "Renault"
    var modele: String = "Megane"
    var immatriculation: String = "BN-104-DS"
    var boite_automatique: Bool = true
    var carburant: String = "Essence"
    
    func description() {
        print("Marque :" + self.marque)
        print("Modele :" + self.modele)
        print("Immatriculation :" + self.immatriculation)
        
        print("Carburant :" + self.carburant)
        
    }
    
}


