//
//  Etudiant.swift
//  Promotion
//
//  Created by Christian on 07/05/2018.
//  Copyright © 2018 Christian. All rights reserved.
//

import UIKit

class Etudiant: Codable {
    var nom : String
    var age : Int
    var numEtudiant : Int;
    
    init(nom: String, age: Int, numEtudiant: Int) {
        self.nom = nom
        self.age = age
        self.numEtudiant = numEtudiant
    }
    
}
