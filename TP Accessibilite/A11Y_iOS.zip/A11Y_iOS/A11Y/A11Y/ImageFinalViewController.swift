//
//  ImageFinalViewController.swift
//  A11Y
//
//  Created by Joshua Hugo Valmy on 15/03/2018.
//  Copyright © 2018 Joshua Hugo Valmy. All rights reserved.
//

import Foundation
import UIKit

class ImageFinalViewController : ViewController{
    var image:UIImage!
    var borderColor:CGColor!
    
    
    @IBOutlet weak var imageFinal: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageFinal.image = image
        imageFinal.layer.borderWidth = 2
        imageFinal.layer.borderColor = borderColor
    }
    
    override func didReceiveMemoryWarning() {
        super.viewDidLoad()
    }
    
    
}
