//
//  ViewController.swift
//  tp6
//
//  Created by Christian on 14/05/2018.
//  Copyright © 2018 Christian. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation


class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var rectangle: UIView!
    @IBOutlet var tap: UITapGestureRecognizer!
    @IBOutlet var long: UILongPressGestureRecognizer!
    @IBOutlet weak var Img: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad();
        // Do any additional setup after loading the view, typically from a nib.
        
    //Q2
        rectangle.backgroundColor = UIColor.blue;
        
    //Q3
        tap.numberOfTapsRequired = 2;
        tap.numberOfTouchesRequired = 1;
        
        
//Q9
    }
    func imagePickerControllerDidCancel(_ picker:   UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController,   didFinishPickingMediaWithInfo info: [String : Any]) {
        Img.image = info[UIImagePickerControllerOriginalImage]  as? UIImage

        // Utilisation de l'image récupérée
        picker.dismiss(animated: true, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func tapAction(_ sender: UITapGestureRecognizer) {
        let r = CGFloat(arc4random() % 255) / 255.0;
        let g = CGFloat(arc4random() % 255) / 255.0;
        let b = CGFloat(arc4random() % 255) / 255.0;
        let c = UIColor(red: r, green: g, blue: b, alpha: 1.0);
        rectangle.backgroundColor = c;
        
    }
    
//Q6
    @IBAction func longAction(_ sender: UILongPressGestureRecognizer) {
        rectangle.backgroundColor = UIColor.blue;
    }
    
    
    @IBAction func buttonAction(_ sender: Any) {
        let movieURL : URL = NSURL.fileURL(withPath:Bundle.main.path(
            forResource: "video",   ofType: "mp4")!)
        let player = AVPlayer(url:movieURL)
        let playerController = AVPlayerViewController()
        playerController.player = player
        self.showDetailViewController(playerController, sender: self)
        player.play()
    }
    
    @IBAction func ajoutPhoto(_ sender: Any) {
        let picker = UIImagePickerController()
         picker.delegate = self
        picker.allowsEditing = false
        picker.sourceType = UIImagePickerControllerSourceType.camera
        picker.cameraDevice = UIImagePickerControllerCameraDevice.rear
        picker.cameraCaptureMode = .photo
        picker.modalPresentationStyle = .fullScreen
        present(picker,animated: true,completion: nil)
      
    }
    
}

