//
//  ViewController.swift
//  TP5
//
//  Created by Camille Guinaudeau on 05/02/2018.
//  Copyright © 2017 Camille Guinaudeau. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var tableView: UITableView!
    var contact : [Personne] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tableView.delegate = self
        tableView.dataSource = self
        
        let p1 = Personne()
        contact.append(p1)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(contact[indexPath.row].description)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        //
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //
        return contact.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "cellule"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
            ?? UITableViewCell(style: .subtitle, reuseIdentifier: cellIdentifier)
        cell.textLabel?.text = contact[indexPath.row].nom
        cell.detailTextLabel?.text = contact[indexPath.row].prenom
        return cell
    }
    
    @IBAction func enregistrementNouvellePersonne(segue : UIStoryboardSegue) {
        let sourceVC = segue.source as! NouvellePersonneViewController
        contact.append(sourceVC.nouvellePersonne)
        print(contact.description)
        tableView.reloadData()
    }
    
    // Question 3
    func getFilePath(nomFichier: String, typeFichier: String) -> String {
        // Initialisation de la variable writePath qui contient le chemin vers le fichier situé dans le repertoire Documents
        // let writePath = ...
        
        let fileManager = FileManager.default
        
        if (!fileManager.fileExists(atPath: writePath)) {
            // Initialisation de la variable sourcepath qui contient le chemin vers le fichier situé dans le repertoire Bundle
            // let sourcepath = ...
            do {
                try fileManager.copyItem(atPath: sourcepath!, toPath: writePath)
            }
            catch {
                print("Erreur au moment de la copie")
            }
        }
        return writePath
    }
}


