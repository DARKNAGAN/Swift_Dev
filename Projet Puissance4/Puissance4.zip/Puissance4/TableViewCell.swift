//
//  TableViewCell.swift
//  Puissance4
//
//  Created by Christian on 15/06/2018.
//  Copyright © 2018 Camille Guinaudeau. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    @IBOutlet weak var joueur1: UILabel!
    @IBOutlet weak var joueur2: UILabel!
    @IBOutlet weak var score1: UILabel!
    @IBOutlet weak var score2: UILabel!
    @IBOutlet weak var nulle: UILabel!
    @IBOutlet weak var dateHour: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
