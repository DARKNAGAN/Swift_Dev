//
//  FormController.swift
//  A11Y
//
//  Created by Joshua Hugo Valmy on 09/03/2018.
//  Copyright © 2018 Joshua Hugo Valmy. All rights reserved.
//

import Foundation
import UIKit


class FormController : UIViewController{
    @IBOutlet weak var txtNom: UITextField!
    @IBOutlet weak var txtPrenom: UITextField!
    @IBOutlet weak var txtTelephone: UITextField!
    @IBOutlet weak var txtMail: UITextField!
    @IBOutlet weak var sgCCiv: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "FormToRes"){
            let vc:FormResController = segue.destination as! FormResController
            

            vc.txtCivNomPre = "\(sgCCiv.titleForSegment(at: sgCCiv.selectedSegmentIndex)!) \(txtNom.text!.uppercased()) \(txtPrenom.text!)"
            vc.txtMail = txtMail.text!
            vc.txtTel = txtTelephone.text!
            
        }
    }
}
