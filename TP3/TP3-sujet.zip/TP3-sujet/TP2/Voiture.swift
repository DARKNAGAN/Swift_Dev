//
//  Voiture.swift
//  TP2
//
//  Created by Camille Guinaudeau on 13/02/2018.
//  Copyright © 2018 Camille Guinaudeau. All rights reserved.
//

import Foundation

class Voiture {
    var marque : String
    var modele : String
    var immatriculation : String
    var boite : Bool
    var carburant : String
    var description : String {
        var typeBoite = "manuelle"
        if (boite) {
            typeBoite = "automatique"
        }
        return "le vehicule \(marque) \(modele) immatriculé \(immatriculation) possede une boite \(typeBoite) et roule avec de \(carburant)"
    }
    
    init(marque: String, modele: String, immatriculation: String, boite: Bool, carburant: String) {
        self.marque = marque
        self.modele = modele
        self.immatriculation = immatriculation
        self.boite = boite
        self.carburant = carburant
    }
    
    convenience init() {
        self.init(marque: "Renault", modele: "Twingo", immatriculation: "AN-925-CJ", boite: false, carburant: "Essence")
    }
}
