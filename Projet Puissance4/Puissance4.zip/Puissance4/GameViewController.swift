//
//  ViewController.swift
//  Puissance4
//
//  Copyright © 2018 Camille Guinaudeau. All rights reserved.
//

import UIKit

class GameViewController: UIViewController {
//Partie
    var partie:Partie?
    
//Grille
    let NBCOLONNE = 7
    let NBLIGNE = 6
    var grille: [[Int]] = [[Int]](repeating:[Int](repeating:-1, count: 7), count:6)
    
// Noms des joueurs
    var txtJoueurJaune = UITextField()
    var txtJoueurRouge = UITextField()
    
    var nomJoueurJaune = "Joueur Jaune"
    var nomJoueurRouge = "Joueur Rouge"
    
    var motifJaune = [0, 0, 0, 0]
    var motifRouge = [1, 1, 1, 1]
    
    var gagnant:Int = 0
    
    @IBOutlet weak var lblTour: UILabel!
    
    
// Images des pions
    let pionVide : UIImage = UIImage(named:"pionVide.png")!
    var pionUn = UIImage()
    var pionDeux = UIImage()
    var couleurUn = UIColor()
    var couleurDeux = UIColor()
    
// Variables d'instance
    var joueurCourant : Int = 0
    var nbCaseLibres : Int = 42
    
    var indice_case_courante : Int = -1
    
// Gestion de l'interface graphique - plateau
    @IBOutlet var caseOutlets: [UIImageView]!
    var taps: [UITapGestureRecognizer] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initPref()
        
// Création des objets de type UITapGestureRecognizer
        for i in 0...caseOutlets.count-1 {
            let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
            caseOutlets[i].isUserInteractionEnabled = true
            caseOutlets[i].addGestureRecognizer(tap)
            print(caseOutlets[i])
            taps.append(tap)
        }
        
// Remplissage du plateau
        for i in 0...caseOutlets.count-1 {
            caseOutlets[i].image = pionVide
        }
    
    }
//Couleur possible Joueur 1
    func initPref(){
        let userDefaults = UserDefaults.standard
    
        switch userDefaults.object(forKey: "color1") as! String {
        case "Vert":
            pionUn = UIImage(named: "pionVert.png")!
            couleurUn = UIColor(red: 40/255, green: 247/255, blue: 45/255, alpha: 1)
        default:
            pionUn = UIImage(named: "pionRouge.png")!
            couleurUn = UIColor(red: 253/255, green: 173/255, blue: 42/255, alpha: 1)
        }
//Couleur possible Joueur 2
        switch userDefaults.object(forKey: "color2") as! String {
        case "Bleu":
            pionDeux = UIImage(named: "pionBleu.png")!
            couleurDeux = UIColor(red: 3/255, green: 32/255, blue: 85/255, alpha: 1)
        default:
            pionDeux = UIImage(named: "pionJaune.png")!
            couleurDeux = UIColor(red: 252/255, green: 13/255, blue: 27/255, alpha: 1)
        }
        
    }
//Choix des 2 noms de joueurs
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let alertController = UIAlertController(title: "Nom des joueurs", message: "Choissisez le nom des joueurs :", preferredStyle: .alert)
        
        alertController.addTextField(configurationHandler: {(textField) in textField.placeholder = "Joueur Jaune"})
        alertController.addTextField(configurationHandler: {(textField) in textField.placeholder = "Joueur Rouge"})
        
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: {(alert:UIAlertAction) in
            self.txtJoueurJaune = alertController.textFields![0]
            self.txtJoueurRouge = alertController.textFields![1]
            self.initialiseJ()
            self.partie = Partie(nomJoueur1: self.nomJoueurJaune, nomJoueur2: self.nomJoueurRouge)
        }))
    
        self.present(alertController, animated: true, completion: nil)
        
        
        
    }
//Info pour les joueurs
    func changeJ(indice: Int){
        print("Changement de joueur")
        var pionCourant : UIImage
        if(joueurCourant == 0){
            pionCourant = pionUn
            joueurCourant = 1
        }
        else{
            pionCourant = pionDeux
            joueurCourant = 0
        }
        changeT()
        caseOutlets[indice].image = pionCourant
    }
//Info pour les joueurs
    func changeT(){
        print("Changement de texte")
        var message: String
        var couleur: UIColor
        if(joueurCourant == 0){
            message = "Le Joueur " + nomJoueurJaune + " joue"
            couleur = couleurUn
        }
        else{
            message = "Le Joueur " + nomJoueurRouge + " joue"
            couleur = couleurDeux
        }
        
        lblTour.text = message
        lblTour.textColor = couleur
    }
//Info pour les joueurs jeu
    func handleTap(_ sender: UITapGestureRecognizer) {
        indice_case_courante = taps.index(of: sender)! as Int
        print("Indice de la case courante : ", indice_case_courante)
        
        joue(indice: indice_case_courante)
        
        let isWin = gagne()
        
        if(isWin.0){
            gagnant = isWin.1
            var message : String
            if(gagnant == 1){
                message = "Le joueur " + nomJoueurRouge + " a gagné !"
            }
            else{
                message = "Le joueur " + nomJoueurJaune + " a gagné !"
            }
            
            partie?.gagne(numJoueur: gagnant)
            
            let alertController = UIAlertController(title: "", message: message, preferredStyle: .alert)
            let actionR = UIAlertAction(title: "Rejouer", style: .default, handler: {(alert:UIAlertAction) in
                self.rejouer()
            })
            let actionF = UIAlertAction(title: "Fermer", style: .destructive, handler: {(alert:UIAlertAction) in
                self.save()
                self.navigationController?.popViewController(animated: true)
            })
            
            alertController.addAction(actionR)
            alertController.addAction(actionF)
            self.present(alertController, animated: true, completion: nil)
        }
        
        if(nbCaseLibres == 0){
            lblTour.text = ""
            
            partie?.nulle()
            
            let alertController = UIAlertController(title: "", message: "Plus de place !", preferredStyle: .alert)
            let actionR = UIAlertAction(title: "Rejouer", style: .default, handler: {(alert:UIAlertAction) in
                self.rejouer()})
            let actionF = UIAlertAction(title: "Fermer", style: .destructive, handler: {(alert:UIAlertAction) in
                self.save()
                self.navigationController?.popViewController(animated: true)
            })
            
            alertController.addAction(actionR)
            alertController.addAction(actionF)
            self.present(alertController, animated: true, completion: nil)
        }
    
    }
//Info pour les joueurs placement
    func joue(indice: Int){
        let indiceDispo = premiereIndiceLibre(indice_case_courante: indice)
        
        print("Indice de la première case disponible : ", indiceDispo)
        
        if(indiceDispo != -1 && nbCaseLibres > 0){
            
            let indicesDispo = conv(indice : indiceDispo)
            
            grille[(indicesDispo.0 - 5) * -1][indicesDispo.1] = joueurCourant
            nbCaseLibres -= 1
            
            changeJ(indice: indiceDispo)
            
            
            print("Nombre de case disponible : ", nbCaseLibres)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
// Puissance 4 option victoire ou non
    func conv(indice: Int) -> (Int, Int){
        let ligne = indice - ((indice/NBLIGNE) * NBLIGNE)
        let colonne = indice/NBLIGNE
        return (ligne, colonne)
    }
    
    
    func premiereIndiceLibre(indice_case_courante: Int) -> Int{
        let numColonne:Int = indice_case_courante / NBLIGNE
        print("Numéro de colonne ", numColonne)
        var i = 0
        
        while i < NBLIGNE{
            //Si une case est libre
            if(grille[(i - 5) * -1][numColonne] == -1){
                return (numColonne * NBLIGNE) + i
            }
            
            i += 1
        }
        
        //Sinon on renvoit -1
        return -1
    }
    
    func verifHorizontal() -> Bool{
        var i = 0
        
        while i < NBLIGNE{
            var ligne:[Int] = [Int](repeating: -1, count: NBCOLONNE)
            for j in 0...NBCOLONNE - 1{
                ligne[j] = grille[i][j]
            }
            
            if(containSubarray(array: ligne, subarray: motifJaune) || containSubarray(array: ligne, subarray: motifRouge)){
                return true
            }
            
            
            i += 1
        }
        
        return false
    }
    
    
    func verifDiagonalGDBH() -> Bool{
        let nbColonne = grille[0].count
        let nbLigne = grille.count
        
        for i in 0...nbLigne - 1{
            let k = i + 1
            var ligne:[Int] = [Int](repeating: -1, count: k)
            var l = 0
            for j in stride(from: i, to: 0-1, by: -1){
                ligne[l] = grille[j][l]
                l += 1
                
                if(containSubarray(array: ligne, subarray: motifJaune) || containSubarray(array: ligne, subarray: motifRouge)){
                    return true
                }
            }
            
            
        }
        
        
        
        for i in 1...nbColonne - 1{
            let k = nbColonne - i
            var ligne:[Int] = [Int](repeating: -1, count: k)
            var l = nbLigne - 1
            var m = 0
            for j in stride(from:i, to: nbColonne, by: 1){
                ligne[m] = grille[l][j]
                l -= 1
                m += 1
            
                
                if(containSubarray(array: ligne, subarray: motifJaune) || containSubarray(array: ligne, subarray: motifRouge)){
                    return true
                }
            }
        }
        
        return false
    }
    
    func verifDiagonalGDHB() -> Bool {
        let nbColonne = grille[0].count
        let nbLigne = grille.count
        
        for i in stride(from: nbColonne - 1, to: 0, by: -1){
            let k = nbColonne - i
            var ligne:[Int] = [Int](repeating: -1, count: k)
            var l = 0
            for j in stride(from:i, to: nbColonne, by: 1){
                ligne[l] = grille[l][j]
                l += 1
                
                if(containSubarray(array: ligne, subarray: motifJaune) || containSubarray(array: ligne, subarray: motifRouge)){
                    return true
                }
            }
            
            
        }
        
        
        for i in 0...nbLigne - 1{
            let k = nbLigne - i
            var ligne:[Int] = [Int](repeating: -1, count: k)
            var l = 0
            for j in stride(from: i, to: nbLigne, by: 1){
                ligne[l] = grille[j][l]
                l += 1
                
                if(containSubarray(array: ligne, subarray: motifJaune) || containSubarray(array: ligne, subarray: motifRouge)){
                    return true
                }
            }
            
        }
        
        return false
    }
    
    func verifVertical() -> Bool{
        var i = 0
        
        while i < NBCOLONNE{
            var ligne:[Int] = [Int](repeating: -1, count: NBLIGNE)
            for j in 0...NBLIGNE - 1{
                ligne[j] = grille[j][i]
            }
            
            if(containSubarray(array: ligne, subarray: motifJaune) || containSubarray(array: ligne, subarray: motifRouge)){
                return true
            }
            
            
            i += 1
        }
        
        return false
    }
    
    func containSubarray(array : [Int], subarray : [Int]) -> Bool{
        if(subarray.count > array.count){
            return false
        }
        
        
        var i = 0
        while i <= (array.count - subarray.count){
            
            var j = 0
            var k = i
            while j < subarray.count{
                if array[k] == subarray[j]{
                    j += 1
                    k += 1
                    continue
                }
                else{
                    break
                }
                
            }
            
            if(j == subarray.count){
                return true
            }
            
            i += 1
            
        }
        
        return false
    }
    
    
    func gagne() -> (Bool, Int){
        let verifG = verifVertical() || verifHorizontal() || verifDiagonalGDBH() || verifDiagonalGDHB()
        return(verifG, (joueurCourant - 1) * -1)
    }
//Autre...
    func rejouer(){
        partie?.rejoue()
        reinitialisation()
    }
    
    func reinitialisation(){
        joueurCourant = 0
        changeT()
        
        for i in caseOutlets{
            i.image = pionVide
        }
        
        
        grille = [[Int]](repeating:[Int](repeating:-1, count: 7), count:6)
        nbCaseLibres = 42
    }
    
    func initialiseJ(){
        nomJoueurRouge = txtJoueurRouge.text!
        nomJoueurJaune = txtJoueurJaune.text!
        
        changeT()
    }
// Met dans scores les infos
    func save(){
        let directories = NSSearchPathForDirectoriesInDomains(.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
        var scores = Scores()
        if let documents = directories.first{
            print(documents)
            let pathScores = documents.appending("/scores.json")
            let url = URL(fileURLWithPath: pathScores)
            var jsonData = Data()
            let jsonDecoder = JSONDecoder()
            do{
                jsonData = try Data(contentsOf:url)
                scores = try jsonDecoder.decode(Scores.self, from: jsonData)
            }
            catch{
                print("Erreur lors de la lecture")
            }
            
            let jsonEncoder = JSONEncoder()
            do{
                scores.ajout(partie: partie!)
                jsonData = try jsonEncoder.encode(scores)
                try jsonData.write(to: url)
            }
            catch{
                print("Erreur lors de l'écriture du fichier")
            }
            
        }
    }

}

