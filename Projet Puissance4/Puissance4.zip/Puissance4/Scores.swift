//
//  Scores.swift
//  Puissance4
//
//  Created by Christian on 04/06/2018.
//  Copyright © 2018 Camille Guinaudeau. All rights reserved.
//

import Foundation

class Scores : Codable{
    var scores : [Partie]
    
    init(){
        scores = []
    }
    
    func ajout(partie : Partie){
        scores.append(partie)
    }
    
    func affiche(nbPartie : Int) -> [Partie]{
        if(scores.count < nbPartie){
            return scores
        }
        else{
            return Array(scores[scores.count - nbPartie...scores.count - 1])
        }
    }
    
    func count() -> Int{
        return scores.count
    }
}
