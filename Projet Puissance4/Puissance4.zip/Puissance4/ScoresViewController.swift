//
//  ScoresViewController.swift
//  Puissance4
//
//  Created by Christian on 15/06/2018.
//  Copyright © 2018 Camille Guinaudeau. All rights reserved.
//

import UIKit

class ScoresViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var nbAffiche:Int = 0
    var scores = Scores()
    
    @IBOutlet weak var table: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        table.delegate = self
        table.dataSource = self
        
        let directories = NSSearchPathForDirectoriesInDomains(.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
        if let documents = directories.first{
            print(documents)
            let pathScores = documents.appending("/scores.json")
            let url = URL(fileURLWithPath: pathScores)
            var jsonData = Data()
            let jsonDecoder = JSONDecoder()
            do{
                jsonData = try Data(contentsOf:url)
                scores = try jsonDecoder.decode(Scores.self, from: jsonData)
                print(scores.count())
            }
            catch{
                print("Erreur lors de la lecture")
            }
            
            
        }
        
        nbAffiche = scores.affiche(nbPartie: 10).count
        
        table.rowHeight = 100
    }
// Nbre de ligne de score
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nbAffiche
    }
// Info à afficher
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print("test")
        let data = scores.affiche(nbPartie: nbAffiche)[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ElementCell") as! TableViewCell
        
        cell.joueur1.text = data.nomJoueur1
        cell.joueur2.text = data.nomJoueur2
        cell.score1.text = String(data.nbPartieG1)
        cell.score2.text = String(data.nbPartieG2)
        cell.nulle.text = String(data.nbPartienulle)
        cell.dateHour.text = "Le \(data.day)/\(data.month)/\(data.year) à  \(data.hour):\(data.minute)"
        
        
        return cell
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
