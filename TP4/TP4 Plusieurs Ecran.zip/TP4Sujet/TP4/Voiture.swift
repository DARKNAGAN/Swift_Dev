//
//  Voiture.swift
//  TPnote
//
//  Created by Camille Guinaudeau on 27/02/2018.
//  Copyright © 2018 Camille Guinaudeau. All rights reserved.
//

import Foundation

class Voiture {
    var modele : String
    var marque : String
    var immatriculation : String
    var boiteAuto : Bool
    var carburant : String
    var enLocation : Bool
    var description : String {
        var embrayage = "Automatique"
        if !boiteAuto {
            embrayage = "Manuel"
        }
        return "\(marque) \(modele) \(immatriculation) \(carburant) \(embrayage)\n"
    }
    
    init(marque : String, modele : String, immatriculation : String, boiteAuto : Bool, carburant : String, enLocation : Bool) {
        self.marque = marque
        self.modele = modele
        self.immatriculation = immatriculation
        self.boiteAuto = boiteAuto
        self.carburant = carburant
        self.enLocation = enLocation
    }
    
    convenience init() {
        self.init(marque : "Renault", modele : "Twingo", immatriculation : "AA-999-CJ", boiteAuto : false, carburant : "Essence", enLocation : false)
    }
}
