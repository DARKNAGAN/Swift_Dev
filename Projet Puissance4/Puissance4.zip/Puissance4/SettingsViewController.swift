//
//  SettingsViewController.swift
//  Puissance4
//
//  Created by Christian on 15/06/2018.
//  Copyright © 2018 Camille Guinaudeau. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
    @IBOutlet weak var scColor1: UISegmentedControl!
    @IBOutlet weak var scColor2: UISegmentedControl!
    @IBOutlet weak var btnMusic: UISwitch!
    @IBOutlet weak var btnSound: UISwitch!

    @IBOutlet weak var btnReinit: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
        initialise()
        
    }
    
// Initialisation des parametres 
    func initialise(){
        print("INIT")
        afficheReg()
        print("#####")
        let userDefaults = UserDefaults.standard
        
        switch userDefaults.object(forKey: "color1") as! String {
        case "Vert":
            scColor1.selectedSegmentIndex = 1
            scColor1.tintColor = UIColor(red: 40/255, green: 247/255, blue: 45/255, alpha: 1)
        default:
            scColor1.selectedSegmentIndex = 0
            scColor1.tintColor = UIColor(red: 253/255, green: 173/255, blue: 42/255, alpha: 1)
        }
        
        switch userDefaults.object(forKey: "color2") as! String {
            case "Bleu":
            scColor2.selectedSegmentIndex = 1
            scColor2.tintColor = UIColor(red: 3/255, green: 32/255, blue: 85/255, alpha: 1)
            default:
            scColor2.selectedSegmentIndex = 0
            scColor2.tintColor = UIColor(red: 252/255, green: 13/255, blue: 27/255, alpha: 1)
        }
        
        btnMusic.isOn = userDefaults.bool(forKey: "music")
        btnSound.isOn = userDefaults.bool(forKey: "sound")
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
// color select 1
    @IBAction func scColor1Select(_ sender: UISegmentedControl) {
        
        switch sender.selectedSegmentIndex {
        case 1:
            scColor1.tintColor = UIColor(red: 44/255, green: 253/255, blue: 30/255, alpha: 1)
            
        default:
            scColor1.tintColor = UIColor(red: 253/255, green: 173/255, blue: 42/255, alpha: 1)
        }
    }
// color select 2
    @IBAction func scColor2Select(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 1:
            scColor2.tintColor = UIColor(red: 20/255, green: 20/255, blue: 250/255, alpha: 1)
            
        default:
            scColor2.tintColor = UIColor(red: 252/255, green: 13/255, blue: 27/255, alpha: 1)
        }
    }
//Initialisation de base
    func reinitialise(){
        scColor1.selectedSegmentIndex = 0
        scColor1.tintColor = UIColor(red: 253/255, green: 173/255, blue: 42/255, alpha: 1)
        scColor2.selectedSegmentIndex = 0
        scColor2.tintColor = UIColor(red: 252/255, green: 13/255, blue: 27/255, alpha: 1)
        btnMusic.isOn = true
        btnSound.isOn = true
    }
// Sauvegarde des parametres
    func save(){
        let userDefaults = UserDefaults.standard
        userDefaults.set(scColor1.titleForSegment(at: scColor1.selectedSegmentIndex), forKey:"color1")
        userDefaults.set(scColor2.titleForSegment(at: scColor2.selectedSegmentIndex), forKey:"color2")
        userDefaults.set(btnMusic.isOn, forKey:"music")
        userDefaults.set(btnSound.isOn, forKey:"sound")
        userDefaults.synchronize()
        
        print("SAVE")
        afficheReg()
        print("######")
    }
    
    @IBAction func btnReiniClick(_ sender: UIButton) {
        reinitialise()
    }
    
    @IBAction func btnValidClick(_ sender: Any) {
        save()
        self.navigationController?.popViewController(animated: true)
    }
// Affichage Parametre
    func afficheReg(){
        let userDefaults = UserDefaults.standard
        
        print(userDefaults.object(forKey: "color1") as! String)
        print(userDefaults.object(forKey: "color2") as! String)
        print(userDefaults.bool(forKey: "music"))
        print(userDefaults.bool(forKey: "sound"))
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
