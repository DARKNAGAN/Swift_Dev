//
//  ViewController.swift
//  TP4
//
//  Created by Camille Guinaudeau on 27/02/2018.
//  Copyright © 2018 Camille Guinaudeau. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var selectedVehicule = Voiture()
    
    
    @IBOutlet weak var table: UITableView!
    var data : [Voiture] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        table.dataSource = self
        table.delegate = self
        
        //Définition des voitures et affichage
        let voiture1 = Voiture(marque: "Renault", modele: "Megane", immatriculation: "AB-654-CD", boiteAuto: false, carburant: "Diesel", enLocation: false)
        let voiture2 = Voiture(marque: " Peugeot", modele: "307", immatriculation: "AV-694-FG", boiteAuto: false, carburant: "GPL", enLocation: true)
        let voiture3 = Voiture(marque: "BMW", modele: "M4", immatriculation: "NB-965-IO", boiteAuto: true, carburant: "Essence", enLocation: false)
        data.append(voiture1)
        data.append(voiture2)
        data.append(voiture3)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Récupérons le bon élément
        let d = data[indexPath.row]
        
        // Créons une cellule
        let cellIdentifier = "ElementCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
            ?? UITableViewCell(style: .subtitle, reuseIdentifier: cellIdentifier)
        
        // On y ajoute les bonnes informations
        cell.textLabel?.text = d.marque
        cell.detailTextLabel?.text = d.modele
        
        if (d.enLocation) {
            cell.accessoryType = .checkmark
        }
        else {
            cell.accessoryType = .none
        }
        
        // On retourne la cellule
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(data[indexPath.row].description)
        
        selectedVehicule = data[indexPath.row]
        performSegue(withIdentifier: "ListToDetail", sender: self)
    }
    
    @IBAction func miseAjourTableView(segue : UIStoryboardSegue){
        print("Mise à jour de la tableView")
        table.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "ListToDetail"){
            let vc:DetailsVehiculeViewController = segue.destination as! DetailsVehiculeViewController
            
            vc.detailVehicule = selectedVehicule
        }
    }
}

