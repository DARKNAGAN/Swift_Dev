//
//  ViewPictureViewController.swift
//  TP8
//
//  Created by Camille Guinaudeau on 01/03/2018.
//  Copyright © 2017 Camille Guinaudeau. All rights reserved.
//

import UIKit

class ViewPictureViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {

    var pictures : [String] = []
    @IBOutlet var collection: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        collection.dataSource = self
        collection.delegate = self

        collection.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return pictures.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cellule", for: indexPath)
        
        let path = pictures[indexPath.row]
        print(path)
        let image = UIImage(contentsOfFile: path)!
        let imageView = UIImageView(image: image)
        cell.backgroundView = imageView
        
        return cell
    }
    
    // Question 3
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // A compléter
        // let index = indexPath.row
    }
}
