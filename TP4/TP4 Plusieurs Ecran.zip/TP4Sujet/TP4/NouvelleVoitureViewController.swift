//
//  NouvelleVoitureViewController.swift
//  TP4
//
//  Created by Christian on 03/04/2018.
//  Copyright © 2018 Christian. All rights reserved.
//

import UIKit

class NouvelleVoitureViewController: UIViewController, UITextFieldDelegate {
    var voitureCourante = Voiture()

    @IBOutlet weak var txtMarque: UITextField!
    @IBOutlet weak var txtModele: UITextField!
    @IBOutlet weak var txtImmat: UITextField!
    @IBOutlet weak var sgtCarbu: UISegmentedControl!
    @IBOutlet weak var swtBoite: UISwitch!
    @IBOutlet weak var swtLoue: UISwitch!
    @IBOutlet weak var btnEnregistrer: UIButton!
    
    @IBAction func changeCarbu(_ sender: UISegmentedControl) {
    }
    
    @IBAction func changeBoite(_ sender: UISwitch) {
    }
    
    @IBAction func changeLoca(_ sender: UISwitch) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        txtModele.delegate = self
        txtMarque.delegate = self
        txtImmat.delegate = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if(!txtModele.text!.isEmpty && !txtMarque.text!.isEmpty && !txtImmat.text!.isEmpty){
            btnEnregistrer.isEnabled = true
        }
        
        if(textField.text!.isEmpty){
            return false
        }
        else{
            return true
        }
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        if(segue.identifier == "NewToList"){
            let vc:ViewController = segue.destination as! ViewController
            
            voitureCourante = Voiture(marque: txtMarque.text!, modele: txtModele.text!, immatriculation: txtImmat.text!, boiteAuto: swtBoite.isOn, carburant: sgtCarbu.titleForSegment(at: sgtCarbu.selectedSegmentIndex)!, enLocation: swtLoue.isOn)
            print(voitureCourante)
            vc.data.append(voitureCourante)
        }
    }
    
}
