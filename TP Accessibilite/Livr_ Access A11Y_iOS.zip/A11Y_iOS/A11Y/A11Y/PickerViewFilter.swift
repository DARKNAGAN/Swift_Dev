//
//  PickerViewFilter.swift
//  A11Y
//
//  Created by Joshua Hugo Valmy on 09/03/2018.
//  Copyright © 2018 Joshua Hugo Valmy. All rights reserved.
//

import Foundation
import UIKit

class PickerViewFilter : UIPickerView, UIPickerViewDelegate, UIPickerViewDataSource{
    var data:[String] = ["Sepia", "Kevin", "Walden"]
    
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return data.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return data[row]
    }
    
    
}
