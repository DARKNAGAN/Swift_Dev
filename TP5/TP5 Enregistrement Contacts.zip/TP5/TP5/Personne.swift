//
//  Personne.swift
//  TP5
//
//  Created by Camille Guinaudeau on 23/02/2017.
//  Copyright © 2017 Camille Guinaudeau. All rights reserved.
//

import Foundation

class Personne {
    var nom : String
    var prenom : String
    var telephone : String
    var mail : String
    var description : String {
       return "\(nom) \(prenom) \(telephone) \(mail)\n"
    }
    
    init(nom : String, prenom : String, telephone : String, mail : String) {
        self.nom = nom
        self.prenom = prenom
        self.telephone = telephone
        self.mail = mail
    }
    
    convenience init() {
        self.init(nom : "Smith", prenom : "John", telephone : "0000000000", mail : "jsmith@gmail.com")
    }
    
}
