//
//  ViewController.swift
//  PremiereInterface
//
//  Created by Christian on 18/03/2018.
//  Copyright © 2018 Christian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //1
    @IBOutlet var vView: UIView!
    @IBOutlet weak var vLabel: UILabel!
    @IBOutlet weak var vSlide: UISlider!
    //2
    @IBOutlet weak var vSwitch: UISwitch!
    @IBOutlet weak var vIndicView: UIActivityIndicatorView!
    @IBOutlet weak var vButton: UIButton!
    //3
    @IBOutlet weak var vSegment: UISegmentedControl!
    //4
    @IBOutlet weak var vStepper: UIStepper!
    @IBOutlet weak var vImageView: UIImageView!


    
    //Q 1-5
    //Question 3: Affiche automatiquement l'action dans l'onglet Connexion inspector selon son type
    
    // Slide change number with label
    @IBAction func fSlide(_ sender: UISlider) {
        let entier = Int(sender.value)
        vLabel.text = "\(entier)"

    }
    //Q 6-7
    @IBAction func fButton(_ sender: UIButton) {
        
        if(vIndicView.isAnimating){
            //Animation stop & Stop title
            vIndicView.stopAnimating()
            vButton.setTitle("Tournez", for: .normal)
            }
        else{
           //Animation load & Tournez title
            vIndicView.startAnimating()
            vButton.setTitle("Stop", for: .normal)
            }
    }
    @IBAction func fSwitch(_ sender: UISwitch) {
        //Lock or free ButtonAnimating
        if(vSwitch.isOn) {
            vButton.isEnabled = true;
        } else {
            vButton.isEnabled = false;
        }
    }

    
    //Q 8-9
    let bckgroundColor = UIColor.blue
    @IBAction func fSegControl(_ sender: UISegmentedControl) {
        //ChangeColor UiView
        let choice = vSegment.selectedSegmentIndex;
        if(choice == 0) {
            self.view.backgroundColor = UIColor.white
        } else if(choice == 1) {
            self.view.backgroundColor = UIColor.red
        } else if(choice == 2) {
            self.view.backgroundColor = UIColor.blue
        } else if(choice == 3) {
            self.view.backgroundColor = UIColor.yellow
        }
    }
    
    //Q 10-14
    let tableauImage = ["1", "2", "3", "4", "5", "6"];
    @IBAction func fStepper(_ sender: UIStepper) {
       //Change ImageView
        let sepperValue = Int(vStepper.value);
        let img2 = UIImage(named: tableauImage[sepperValue]);
        vImageView.image = img2;
    }
    
    
    
    
    //0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //Q10
        let img1 = UIImage(named: "1");
        vImageView.image = img1
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

