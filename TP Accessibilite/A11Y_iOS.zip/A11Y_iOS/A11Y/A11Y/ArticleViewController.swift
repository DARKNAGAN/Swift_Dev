//
//  ArticleViewController.swift
//  A11Y
//
//  Created by Joshua Hugo Valmy on 14/03/2018.
//  Copyright © 2018 Joshua Hugo Valmy. All rights reserved.
//

import Foundation
import UIKit

class ArticleViewController : UIViewController{
    @IBOutlet weak var lblNbArticle: UILabel!

    
    
    
    var nbArticle1:Int = 0
    var nbArticle2:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        refreshNbArticle()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func refreshNbArticle(){
        lblNbArticle.text = String(nbArticle1 + nbArticle2) + " " + ((nbArticle1 + nbArticle2) > 1 ? "articles" : "article")
    }
    

    @IBAction func btnClickArt1(_ sender: UIButton) {
        nbArticle1 += 1
        refreshNbArticle()
    }
    @IBAction func btnClickArt2(_ sender: UIButton) {
        nbArticle2 += 1
        refreshNbArticle()
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "ArticleToPanier"){
            let vc:PanierViewController = segue.destination as! PanierViewController
            vc.nbArticle1 = nbArticle1
            vc.nbArticle2 = nbArticle2
        }
    }
    
    
}
