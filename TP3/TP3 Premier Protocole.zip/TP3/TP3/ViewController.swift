//
//  ViewController.swift
//  TP2
//
//  Created by Camille Guinaudeau on 13/02/2018.
//  Copyright © 2018 Camille Guinaudeau. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    var tableauVoitures : [Voiture] = []
    
    @IBOutlet weak var textMarque: UITextField!
    @IBOutlet weak var textModele: UITextField!
    @IBOutlet weak var textImmatriculation: UITextField!
    @IBOutlet weak var Typecarburant: UISegmentedControl!
    @IBOutlet weak var boiteAutomatique: UISwitch!
    @IBOutlet weak var affichageVoiture: UILabel!
    @IBOutlet weak var boutonEnregistrer: UIButton!
    @IBOutlet weak var labelImmatriculation: UILabel!
    
    @IBAction func EnregistrerNouvelleVoiture(_ sender: Any) {
        let nouvelleVoiture = Voiture()
        nouvelleVoiture.marque = textMarque.text!
        nouvelleVoiture.modele = textModele.text!
        nouvelleVoiture.immatriculation = textImmatriculation.text!
        var carbu = ""
        if (Typecarburant.selectedSegmentIndex == 0) {
            carbu = "Essence"
        }
        if (Typecarburant.selectedSegmentIndex == 1) {
            carbu = "Diesel"
        }
        if (Typecarburant.selectedSegmentIndex == 2) {
            carbu = "Electrique"
        }
        nouvelleVoiture.carburant = carbu
        nouvelleVoiture.boite = boiteAutomatique.isOn
        
        affichageVoiture.text =  nouvelleVoiture.description
        tableauVoitures.append(nouvelleVoiture)
        print("Nous avons enregistré \(tableauVoitures.count) voitures, les voici : ")
        for voiture in tableauVoitures {
            print(voiture.description)
        }
        self.cleanInterface()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.cleanInterface()
        
        let v1 = Voiture()
        let v2 = Voiture(marque: "Fiat", modele: "Uno", immatriculation: "XX-123-GT", boite: true, carburant: "Diesel")
        print(v1.description)
        print(v2.description)
        
        
        
        /* Question 1 */
        textMarque.delegate = self;
        textModele.delegate = self;
        textImmatriculation.delegate = self;
        
        /* Question 2 */
        boutonEnregistrer.isEnabled = false;
        
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func cleanInterface() {
        textMarque.text = ""
        textModele.text = ""
        textImmatriculation.text = ""
        Typecarburant.selectedSegmentIndex = UISegmentedControlNoSegment
        boiteAutomatique.isOn = true
        //boutonEnregistrer.isEnabled = false
    }
    
    /* Question 4 à 8 */
    //Note : Un probleme empeche le changement de textView apres la sauvegade. 
    
    //Q3( return false)? : Lorsque le champ est false on ne peu pas passer au suivant!
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        print("En cours d'édition");
        return true;
        
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        print("En cours d'édition");
    }    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case textMarque:
            textModele.becomeFirstResponder()
        case textModele:
            textImmatriculation.becomeFirstResponder()
        default:
            textField.resignFirstResponder()
        }
        return true;
    }
    
    
    
    func textFieldShouldEndEditing(_ textField: UITextField)->Bool {
        if(textField == textImmatriculation && invalidImmatriculation()){
            textImmatriculation.backgroundColor  = UIColor.red;
            labelImmatriculation.text = "L'immatriculation doit avoir le format AA-000-DD";
            boutonEnregistrer.isEnabled = false;
            return false;
        } else{
            textImmatriculation.backgroundColor  = UIColor.white;
            labelImmatriculation.text = "";
            boutonEnregistrer.isEnabled = true;
            return true;
        }
    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        checkEmptyField();
        print("Fin d'édition");
    }
    
    
    /* Verification que chaque champ sois rempli */
    func checkEmptyField(){
        if( (textMarque.text != "") && (textModele.text != "") && (textImmatriculation.text != "") && (Typecarburant.selectedSegmentIndex != -1) ){
            boutonEnregistrer.isEnabled = true;
        } else {
            boutonEnregistrer.isEnabled = false;
        }
    }
    @IBAction func segmentAction(_ sender: Any) {
        checkEmptyField();
    }
    
    
    
    func invalidImmatriculation()->Bool {
        let regex = try! NSRegularExpression(pattern: "^[A-Z]{2}-[0-9]{3}-[A-Z]{2}$");
        let matches = regex.numberOfMatches(in: textImmatriculation.text!,options:[], range:NSRange(location: 0, length: (textImmatriculation.text?.count)!))
        if(matches > 0){
            return false;
        } else {
            return true;
        }
        
    }
    // toucher espace vide ferme clavier (ne fonctionne pas pour Immat)
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        labelImmatriculation.resignFirstResponder()
    }
}

