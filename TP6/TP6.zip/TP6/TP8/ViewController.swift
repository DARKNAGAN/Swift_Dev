//
//  ViewController.swift
//  TP8
//
//  Created by Camille Guinaudeau on 01/03/2018.
//  Copyright © 2017 Camille Guinaudeau. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate,
UINavigationControllerDelegate {
    let picker = UIImagePickerController()
    
    @IBAction func takePicture(_ sender: Any) {
        
        picker.delegate = self
        
        picker.allowsEditing = false
        picker.sourceType = UIImagePickerControllerSourceType.camera
        picker.cameraDevice =
            UIImagePickerControllerCameraDevice.rear
        picker.cameraCaptureMode = .photo
        picker.modalPresentationStyle = .fullScreen
        present(picker,animated: true,completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func imagePickerControllerDidCancel(_ picker:
        UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let image = info[UIImagePickerControllerOriginalImage] as! UIImage
        let newImage = resizeImage(image: image, newWidth: 256)
        
        if let data = UIImagePNGRepresentation(newImage) {
            let documents =
                NSSearchPathForDirectoriesInDomains(.documentDirectory,
                                                    .userDomainMask, true)[0]
            let alea = arc4random() % 255;
            let pathname = documents.appending("/\(alea).png")
            let url : URL = URL(fileURLWithPath: pathname)
            do {
                try data.write(to: url)
            }
            catch {
                print("Erreur au moment de l'enregistrement")
            }
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func resizeImage(image: UIImage, newWidth: CGFloat) -> UIImage {
        
        let scale = newWidth / image.size.width
        let newHeight = image.size.height * scale
        let size = CGSize(width: newWidth, height: newHeight)
        UIGraphicsBeginImageContext(size)
        let rect = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: newWidth, height: newHeight))
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "visualisation" {
            let vp = segue.destination as! ViewPictureViewController
            let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
            let fileManager = FileManager.default
            
            do {
                var documents : [String] = []
                vp.pictures = []
                try documents = fileManager.contentsOfDirectory(atPath: path)
                for d in documents {
                    vp.pictures.append("\(path)/\(d)")
                }
            }
            catch {
                print("Erreur lors de la récupération des documents")
            }
            
            
            
        }
    }


}

