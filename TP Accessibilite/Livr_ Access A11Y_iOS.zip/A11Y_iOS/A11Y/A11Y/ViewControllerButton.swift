//
//  ViewControllerButton.swift
//  A11Y
//
//  Created by Joshua Hugo Valmy on 09/03/2018.
//  Copyright © 2018 Joshua Hugo Valmy. All rights reserved.
//

import Foundation
import UIKit
import QuartzCore
import CoreImage
import CoreGraphics

class ViewControllerButton : UIViewController{
    
    var firstImg:UIImage!;
    var contrastFilter: CIFilter!;
    var invertFilter: CIFilter!;
    var context = CIContext();
    var outputImage = CIImage();
    var newUIImage = UIImage();
    var tmpImage = UIImage();
    var ciimage:CIImage!;
    var cgimg:CGImage!;
    
    var isInvert:Bool = false;
    
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var scColor: UISegmentedControl!
    
    
    @IBOutlet weak var swtInvert: UISwitch!
    
    
    @IBOutlet weak var slContraste: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        img.layer.borderColor = UIColor.black.cgColor
        img.layer.borderWidth = 2

        
        firstImg = img.image
        context = CIContext(options: nil)
        contrastFilter = CIFilter(name: "CIColorControls")
        invertFilter = CIFilter(name: "CIColorInvert")
        
        print("ViewControllerButton")
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        
    }
    
    
    @IBAction func reinitialize(_ sender: Any) {
        img.image = firstImg
        img.layer.borderColor = UIColor.black.cgColor
        
        scColor.isSelected = false
        slContraste.value = slContraste.maximumValue
        
        swtInvert.isOn = false
    
    }
    
    
    
    
    
    
    
    
   
    
    @IBAction func sgClick(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            img.layer.borderColor = UIColor.red.cgColor
        case 1:
            img.layer.borderColor = UIColor.blue.cgColor
        case 2:
            img.layer.borderColor = UIColor.green.cgColor
        default:
            img.layer.borderColor = UIColor.black.cgColor
        }
    
    }
    
    @IBAction func sldConstChange(_ sender: UISlider) {
        if(isInvert){
            tmpImage = firstImg
            
            img.image = constrast(value: sender.value, uiimage: invert(uiimage: tmpImage))
        }
        else{
            img.image = constrast(value: sender.value, uiimage: firstImg)
        }

    }
    
    @IBAction func colorInvertClick(_ sender: UISwitch) {
        if(sender.isOn){
            isInvert = true;
        }
        else{
            isInvert = false;
        }
        img.image = invert(uiimage: img.image!)
    }
    
    
    func constrast(value: Float, uiimage: UIImage) -> UIImage{
        ciimage = CIImage(image: uiimage)
        
        
        contrastFilter.setValue(ciimage, forKey: "inputImage")
        contrastFilter.setValue(value, forKey: "inputContrast")
        
        outputImage = contrastFilter.outputImage!
        cgimg = context.createCGImage(outputImage, from: outputImage.extent)
        newUIImage = UIImage(cgImage: cgimg!)
        return newUIImage;
    }
    
    func invert(uiimage : UIImage) -> UIImage{
        ciimage = CIImage(image: uiimage)
        
        contrastFilter.setValue(ciimage, forKey: "inputImage")
        invertFilter.setValue(ciimage, forKey: kCIInputImageKey)
        
        outputImage = invertFilter.outputImage!
        cgimg = context.createCGImage(outputImage, from: outputImage.extent)
        newUIImage = UIImage(cgImage: cgimg!)
        return newUIImage
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "ImageToSave"){
            let vc:ImageFinalViewController = segue.destination as! ImageFinalViewController
            
            vc.image = img.image
            vc.borderColor = img.layer.borderColor
        }
    }
    
}
