//
//  ViewController.swift
//  PremierPickerView
//
//  Created by Christian on 18/03/2018.
//  Copyright © 2018 Christian. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    @IBOutlet weak var vPickerView: UIPickerView!
    @IBOutlet weak var vLabel: UILabel!
    @IBOutlet weak var vButton: UIButton!
    
    let data1 : [String] = ["Café", "Thé", "Cappucino", "Tisane"]
    let data2 : [String] = ["chaud", "tiède", "froid"]
    let data3 : [String] = ["sucré", "faiblement sucré", "non sucré"]
    var boisson : String  = ""
    var chaleur : String = ""
    var sucre : String = ""
    
    
    //0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        vPickerView.dataSource = self
        vPickerView.delegate = self
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 3
        
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if component == 0 {
            return data1.count
        } else if component == 1 {
            return data2.count
        }
            return data3.count
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if component == 0 {
            return data1[row]
        } else if component == 1 {
            return data2[row]
        }
            return data3[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        boisson = data1[pickerView.selectedRow(inComponent: 0)]
        chaleur = data2[pickerView.selectedRow(inComponent: 1)]
        sucre = data3[pickerView.selectedRow(inComponent: 2)]
        
      
        /* Observer avec ou sans dans mon cas
         if component == 0 {
            boisson = data1[row]
        } else if component == 1{
            chaleur = data2[row]
        } else {
            sucre = data3[row]
        }*/
        
        
    }
    @IBAction func CommandeButton(_ sender: UIButton) {
        vLabel.text = "\(boisson) \(chaleur) \(sucre)"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

